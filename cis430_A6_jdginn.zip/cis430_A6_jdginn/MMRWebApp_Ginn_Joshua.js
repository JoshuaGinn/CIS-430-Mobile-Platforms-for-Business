// Joshua Ginn, A6, CIS430, 1:30
"use strict"; 

var startingAge             = 0;
var startingSalary          = 0;
var annualRaisePercent      = 0;
var retirementAge           = 0;
var annualSavingsPercent    = 0;
var interestRatePercent     = 0;
    
var currentSalary;
var currentSavings;
var currentInterest;
var currentRetirement;

var yearsToInvest;
var retirementFund;
var lifetimeSalary = 0;
var totalSaved = 0;
var earnedInterest = 0;
var table;

function clearInputs(form) {
	// alert("function clearInputs() is running");
	var formElements = form.elements;
	for (var i=0; i< formElements.length; i++)
		formElements[i].value="";
}

function loadDefaults(form) {
	// alert("function loadDefaults() is running");
	form.reset();
}


function getNumValue(id) {
	return Number(document.getElementById(id).value);
}

function displayTableHeader() {

    table = document.getElementById("amortTable");
    table.innerHTML = ""; // Clears prevous table, if any.

    let row = table.insertRow(0);
            
    let cell1 = row.insertCell(0);
    let cell2 = row.insertCell(1);
    let cell3 = row.insertCell(2);
    let cell4 = row.insertCell(3);
    let cell5 = row.insertCell(4);

    cell1.className = 'cellEntry';
    cell2.className = 'cellEntry';
    cell3.className = 'cellEntry';
    cell4.className = 'cellEntry';
    cell5.className = 'cellEntry';
            
    cell1.innerHTML = 'Age';
    cell2.innerHTML = 'Salary';
    cell3.innerHTML = 'Savings';
    cell4.innerHTML = 'Interest';
    cell5.innerHTML = 'Retirement';
}

function makeMeRich(form) {


    if (!form.checkValidity()) {
		alert("See highlighted input boxes, there are input errors");
	} else {
        
        // Reinitialize variables to zero prior to calculations
        currentSalary = null;
        currentSavings = 0;
        currentInterest = 0;
        currentRetirement = 0;
        retirementFund = 0;
        lifetimeSalary = 0;
        totalSaved = 0;
        earnedInterest = 0;


        startingAge          = getNumValue('startingAge');
		startingSalary 	     = getNumValue('startingSalary');
        annualSavingsPercent = getNumValue('annualSavings');
		annualRaisePercent   = getNumValue('annualRaise');
		retirementAge 	     = getNumValue('retirementAge');
		interestRatePercent  = getNumValue('interestRate');
        
        yearsToInvest = retirementAge - startingAge;

        displayTableHeader(); // Clears Table contents, displays Table header row.
    
        table = document.getElementById("amortTable");

        let counter = 1; // row number being inserted.

        for (let year = startingAge; year <= retirementAge; year++) {

            if (currentSalary == null){
                currentSalary = startingSalary
            } else {
                currentSalary = currentSalary + (currentSalary * annualRaisePercent/100)
            }

            currentSavings = currentSalary * (annualSavingsPercent/100);

            if (currentInterest == null) {
                currentInterest = (currentSavings * (interestRatePercent/100))
            } else {
                currentInterest = (currentRetirement * (interestRatePercent/100)) + (currentSavings * (interestRatePercent/100))
            }
            
            if (currentRetirement == null) {
                currentRetirement = currentSavings + currentInterest
            } else {
                currentRetirement = currentRetirement + currentSavings + currentInterest
            }
            
            let row = table.insertRow(counter);
            
            let cell1 = row.insertCell(0);
            let cell2 = row.insertCell(1);
            let cell3 = row.insertCell(2);
            let cell4 = row.insertCell(3);
            let cell5 = row.insertCell(4);

            cell1.className = 'cellEntry';
            cell2.className = 'cellEntry';
            cell3.className = 'cellEntry';
            cell4.className = 'cellEntry';
            cell5.className = 'cellEntry';
             
            currentSalary = currentSalary
            currentSavings = currentSavings
            currentInterest = currentInterest
            currentRetirement = currentRetirement

            cell1.innerHTML = year;
            cell2.innerHTML = formatNumberWithCommas(currentSalary);
            cell3.innerHTML = formatNumberWithCommas(currentSavings);
            cell4.innerHTML = formatNumberWithCommas(currentInterest);
            cell5.innerHTML = formatNumberWithCommas(currentRetirement);


            counter += 1; // Moves counter to next row
        
            retirementFund = currentRetirement;
            lifetimeSalary = lifetimeSalary + currentSalary;
            totalSaved = totalSaved + currentSavings;
            earnedInterest = earnedInterest + currentInterest;
        }

        populateSummaryTable();

        console.log(Math.round(yearsToInvest), ": Years to invest")
        console.log(Math.round(retirementFund), ": Retirement Fund")
        console.log(Math.round(lifetimeSalary), ": Lifetime Salary")
        console.log(Math.round(totalSaved), ": Total Saved")
        console.log(Math.round(earnedInterest), ": Earned Interest")

    }

}

function populateSummaryTable() {

    let summaryTableElements = document.getElementsByTagName('th');
    summaryTableElements[6].innerHTML = formatNumberWithCommas(yearsToInvest);
    summaryTableElements[8].innerHTML = formatNumberWithCommas(retirementFund);
    summaryTableElements[10].innerHTML = formatNumberWithCommas(lifetimeSalary);
    summaryTableElements[12].innerHTML = formatNumberWithCommas(totalSaved);
    summaryTableElements[14].innerHTML = formatNumberWithCommas(earnedInterest);
}